# Pulse Terminal for Android

This is an Android WebView app wrapping the Pulse Terminal market dashboard. The HTML interface is bundled in the APK, so it opens as an Android app and keeps watchlist/settings/history locally on the device.

## Build an APK with GitHub Actions
1. Create a GitHub repository and upload the contents of this folder.
2. Open the repository's **Actions** tab.
3. Run **Build Android APK** (or push to `main`/`master`).
4. Open the successful workflow run and download the `pulse-terminal-android-debug` artifact.
5. Extract it; the installable file is `app-debug.apk`.

## Build locally
Requires JDK 17 and Gradle 8.9:
```bash
gradle assembleDebug
```
APK output: `app/build/outputs/apk/debug/app-debug.apk`.

## Market data and limitations
- Uses Binance public USDⓈ-M Futures REST and WebSocket market-data endpoints. No exchange API key is requested.
- The browser-side scanner runs while the app is open. Android may suspend background activity when the app is closed or the device sleeps.
- For continuous monitoring and persistent cloud signal history, deploy the companion FastAPI backend from the separate Pulse Terminal V2 project and configure the frontend API base URL to your hosted service.
- No order placement, exchange account connection, custody, or financial advice.
- POA figures are simplified estimates and omit fees, funding, slippage, maintenance-margin tiers and liquidation details.

## Package details
- Application ID: `io.pulseterminal.app`
- Minimum Android: 6.0 (API 23)
- Target SDK: 35
- Version: 1.0.0
